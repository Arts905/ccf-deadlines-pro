
from setuptools import setup, find_packages

setup(
    name='ccfddl',
    version='0.1',
    packages=find_packages(),
    license='MIT',
    description='ccfddl cli',
    author='0x4f5da2',
    author_email='me@4f5da2.com'
)
